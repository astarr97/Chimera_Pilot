#!/bin/bash
#SBATCH --time=24:00:00
#SBATCH --ntasks=8
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=16G

./apps/cellranger-7.1.0/cellranger count --localcores=8 --nosecondary --force-cells=8000 --id RM2_Mouse_Rat2_P --transcriptome /scratch/users/astarr97/Chimera/mouse_and_rat --fastqs /scratch/users/astarr97/Chimera/RM2_P
