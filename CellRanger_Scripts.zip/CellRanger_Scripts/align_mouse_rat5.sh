#!/bin/bash
#SBATCH --time=24:00:00
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=4G

./apps/cellranger-7.1.0/cellranger count --localcores=8 --nosecondary --force-cells=8000 --id MR2_Mouse_Rat1 --transcriptome /scratch/users/astarr97/Chimera/mouse_and_rat --fastqs /scratch/users/astarr97/Chimera/MR2
