#!/bin/bash
#SBATCH --time=24:00:00
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8G

./apps/cellranger-7.1.0/cellranger count --localcores=8 --nosecondary --force-cells=8000 --id WT_Mouse_Rat1_P --transcriptome /scratch/users/astarr97/Chimera/mouse_and_rat --fastqs /scratch/users/astarr97/Chimera/WT_P
