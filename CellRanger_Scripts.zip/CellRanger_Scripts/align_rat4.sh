#!/bin/bash
#SBATCH --time=48:00:00
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=16G

./apps/cellranger-7.1.0/cellranger count --localcores=8 --nosecondary --expect-cells=10000 --id MR1_Rat2_P --transcriptome /scratch/users/astarr97/Chimera/rat_prelim --fastqs /scratch/users/astarr97/Chimera/MR1_P
