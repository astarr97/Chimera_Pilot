#!/bin/bash
#SBATCH --time=72:00:00
#SBATCH -p hbfraser
#SBATCH --mem=128GB
#SBATCH -c 1

wget https://ftp.ensembl.org/pub/release-109/fasta/mus_musculus/dna/Mus_musculus.GRCm39.dna.toplevel.fa.gz
wget https://ftp.ensembl.org/pub/release-109/fasta/rattus_norvegicus/dna/Rattus_norvegicus.mRatBN7.2.dna.toplevel.fa.gz
wget https://ftp.ensembl.org/pub/release-109/gtf/mus_musculus/Mus_musculus.GRCm39.109.gtf.gz
wget https://ftp.ensembl.org/pub/release-109/gtf/rattus_norvegicus/Rattus_norvegicus.mRatBN7.2.109.gtf.gz

gunzip *.gtf.gz
gunzip *.fa.gz

./cellranger-7.1.0/cellranger mkgtf Mus_musculus.GRCm39.109.gtf Mus_musculus.GRCm39.109.filtered.gtf --attribute=gene_biotype:protein_coding --attribute=gene_biotype:lncRNA --attribute=gene_biotype:antisense --attribute=gene_biotype:snoRNA  --attribute=gene_biotype:snRNA  --attribute=gene_biotype:miRNA  --attribute=gene_biotype:scaRNA
./cellranger-7.1.0/cellranger mkgtf Rattus_norvegicus.mRatBN7.2.109.gtf Rattus_norvegicus.mRatBN7.2.109.filtered.gtf --attribute=gene_biotype:protein_coding --attribute=gene_biotype:lncRNA --attribute=gene_biotype:antisense --attribute=gene_biotype:snoRNA  --attribute=gene_biotype:snRNA  --attribute=gene_biotype:miRNA  --attribute=gene_biotype:scaRNA

./cellranger-7.1.0/cellranger mkref --genome=mouse --fasta=Mus_musculus.GRCm39.dna.toplevel.fa --genes=Mus_musculus.GRCm39.109.filtered.gtf --genome=rat --fasta=Rattus_norvegicus.mRatBN7.2.dna.toplevel.fa --genes=Rattus_norvegicus.mRatBN7.2.109.filtered.gtf
./cellranger-7.1.0/cellranger mkref --genome=mouse_prelim --fasta=Mus_musculus.GRCm39.dna.toplevel.fa --genes=Mus_musculus.GRCm39.109.filtered.gtf
./cellranger-7.1.0/cellranger mkref --genome=rat_prelim --fasta=Rattus_norvegicus.mRatBN7.2.dna.toplevel.fa --genes=Rattus_norvegicus.mRatBN7.2.109.filtered.gtf
